const { response } = require("express");
const express = require("express");
const router = express.Router();

const bcrypt = require('bcryptjs');
const Usuario = require("../models/modelo-usuario");

router.get("/", async (req, res, next) => {
  let usuarios;
  try {
    usuarios = await Usuario.find({}, "-password");
  } catch (err) {
    const error = new Error("Ha ocurrido un error en la recuperación de datos");
    error.code = 500;
    return next(error);
  }
  res.status(200).json({
    mensaje: "Todos los usuarios",
    usuarios: usuarios,
  });
});


router.get("/:id", async (req, res, next) => {
  const idUsuario = req.params.id;
  let usuario;
  try {
    usuario = await Usuario.findById(idUsuario);
  } catch (err) {
    const error = new Error(
      "Ha habido algún error. No se han podido recuperar los datos"
    );
    error.code = 500;
    return next(error);
  }
  if (!usuario) {
    const error = new Error(
      "No se ha podido encontrar un usuario con el id proporcionado"
    );
    error.code = 404;
    return next(error);
  }
  res.json({
    mensaje: "Usuario encontrado",
    usuario: usuario,
  });
});


router.post("/", async (req, res, next) => {
  const { nombre, email, password } = req.body;
  let existeUsuario;
  try {
    existeUsuario = await Usuario.findOne({
      email: email,
    });
  } catch (err) {
    const error = new Error(err);
    error.code = 500;
    return next(error);
  }

  if (existeUsuario) {
    const error = new Error("Ya existe un usuario con ese e-mail.");
    error.code = 401;
    return next(error);
  } else {
    let hashedPassword;

    try {
      hashedPassword = await bcrypt.hash(password, 12);
    } catch (error) {
      const err = new Error("No se han podido guardar los datos");
      err.code = 500;
      return next(err);
    }
    console.log(hashedPassword)
    const nuevoUsuario = new Usuario({
      nombre,
      email,
      password: hashedPassword,

    });
    try {
      await nuevoUsuario.save();
    } catch (error) {
      const err = new Error("No se han podido guardar los datos");
      err.code = 500;
      return next(err);
    }

    res.status(201).json({
      usuario: nuevoUsuario,
    });
  }
});


router.post("/login", async (req, res, next) => {
  const { email, password } = req.body;
  let usuarioExiste;
  try {
    usuarioExiste = await Usuario.findOne({

      email: email,
    });
  } catch (error) {
    const err = new Error(
      "No se ha podido realizar la operación. Pruebe más tarde"
    );
    err.code = 500;
    return next(err);
  }
  console.log(usuarioExiste);
  console.log("probando probando");
  if (!usuarioExiste) {
    const error = new Error(
      "No se ha podido identificar al docente. Credenciales erróneos"
    );
    error.code = 422;
    return next(error);
  }

  let esValidoPassword = false;
  esValidoPassword = bcrypt.compareSync(password, usuarioExiste.password);
  if (!esValidoPassword) {
    const error = new Error(
      "No se ha podido identificar al usuario !"
    );
    error.code = 401;
    return next(error);
  }
  res.json({
    mensaje: "Usuario logueado",
    email: usuarioExiste.email,
  });
});


router.get("/buscar/:busca", async (req, res, next) => {
  const search = req.params.busca;
  let usuarios;
  try {
    usuarios = await Usuario.find({
      nombre: { $regex: search, $options: "i" },
    });
  } catch (err) {
    const error = new Error("Ha ocurrido un error en la recuperación de datos");
    error.code = 500;
    return next(error);
  }
  res.status(200).json({ mensaje: "Usuarios encontrados", usurios: usuarios });
});

module.exports = router;
