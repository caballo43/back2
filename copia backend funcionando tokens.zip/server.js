// index.js
const mongoose = require("mongoose");
const express = require("express");

const app = express();

app.use(express.json());

const rutasUsuarios = require("./routes/rutas-usuarios");
app.use("/api/usuarios", rutasUsuarios);

app.use((req, res) => {

  res.status(404);
  res.json({
    mensaje: "Información no encontrada",
  });
});

mongoose
  .connect(
    "mongodb+srv://a4caballo:Adjust123@cluster0.ymzcq8b.mongodb.net/proyecto?retryWrites=true&w=majority"
  )
  .then(() => {
    console.log("🤣🤣 Conectado con éxito a Atlas");
    app.listen(5000, () => console.log(`🎶 Escuchando en puerto 5000`));
  })
  .catch((error) => console.log(error));
